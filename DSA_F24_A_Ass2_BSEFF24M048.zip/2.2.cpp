//#include<iostream>
//#include<fstream>
//#include<string>
//
//using namespace std;
//
//class Editor
//{
//private:
//
//    string text;
//    string currentFile;
//
//    string fontName;
//    int fontSize;
//    string textColor;
//
//public:
//
//    Editor()
//    {
//        text = "";
//        currentFile = "";
//
//        fontName = "arial";
//        fontSize = 12;
//        textColor = "White";
//    }
//
//    void newFile()
//    {
//        text = "";
//        currentFile = "";
//
//        cout << "\nnew file created\n";
//    }
//
//    void typeText()
//    {
//        cin.ignore();
//
//        string line;
//
//        cout << "\nenter text (type END on new line to stop)\n\n";
//
//        while (true)
//        {
//            getline(cin, line);
//
//            if (line == "END")
//            {
//                break;
//            }
//
//            text += line;
//            text += "\n";
//        }
//
//        cout << "\ntext added successfully\n";
//    }
//
//    void displayText()
//    {
//        cout << "\n-------- FILE DAta-----------\n\n";
//
//        if (text == "")
//        {
//            cout << "file is empty\n";
//        }
//        else
//        {
//            cout << text << endl;
//        }
//    }
//
//    void saveFile()
//    {
//        if (currentFile == "")
//        {
//            cin.ignore();
//
//            cout << "\nenter file name : ";
//            getline(cin, currentFile);
//        }
//
//        ofstream fout(currentFile);
//
//        fout << text;
//
//        fout.close();
//
//        cout << "\nfile saved successfully\n";
//    }
//
//    void saveAs()
//    {
//        cin.ignore();
//
//        string newName;
//
//        cout << "\nenter new file name : ";
//        getline(cin, newName);
//
//        ofstream fout(newName);
//
//        fout << text;
//
//        fout.close();
//
//        currentFile = newName;
//
//        cout << "\nfile saved with new name\n";
//    }
//
//    void openFile()
//    {
//        cin.ignore();
//
//        string fileName;
//
//        cout << "\nEnter file name to open : ";
//        getline(cin, fileName);
//
//        ifstream fin(fileName);
//
//        if (!fin)
//        {
//            cout << "\nFile not found\n";
//            return;
//        }
//
//        text = "";
//
//        string line;
//
//        while (getline(fin, line))
//        {
//            text += line;
//            text += "\n";
//        }
//
//        fin.close();
//
//        currentFile = fileName;
//
//        cout << "\nFile Opened Successfully\n";
//    }
//
//    void closeFile()
//    {
//        text = "";
//        currentFile = "";
//
//        cout << "\nFile Closed\n";
//    }
//
//    void deleteText()
//    {
//        if (text == "")
//        {
//            cout << "\nNothing to delete\n";
//            return;
//        }
//
//        int num;
//
//        cout << "\nHow many characters remove from end : ";
//        cin >> num;
//
//        while (num > 0 && text.length() > 0)
//        {
//            text.pop_back();
//            num--;
//        }
//
//        cout << "\nText Deleted\n";
//    }
//
//    void findWord()
//    {
//        cin.ignore();
//
//        string word;
//
//        cout << "\nEnter word to find : ";
//        getline(cin, word);
//
//        int pos = text.find(word);
//
//        if (pos == -1)
//        {
//            cout << "\nWord not found\n";
//        }
//        else
//        {
//            cout << "\nWord found at index : " << pos << endl;
//        }
//    }
//
//    void replaceWord()
//    {
//        cin.ignore();
//
//        string oldWord;
//        string newWord;
//
//        cout << "\nEnter word to replace : ";
//        getline(cin, oldWord);
//
//        cout << "Enter new word : ";
//        getline(cin, newWord);
//
//        int pos = text.find(oldWord);
//
//        if (pos == -1)
//        {
//            cout << "\nWord not found\n";
//        }
//        else
//        {
//            text.replace(pos, oldWord.length(), newWord);
//
//            cout << "\nReplacement Done\n";
//        }
//    }
//
//    void changeColor()
//    {
//        cin.ignore();
//
//        cout << "\nEnter text color : ";
//        getline(cin, textColor);
//
//        cout << "\nText Color Changed To " << textColor << endl;
//    }
//
//    void changeFont()
//    {
//        cin.ignore();
//
//        cout << "\nEnter font name : ";
//        getline(cin, fontName);
//
//        cout << "\nFont Changed To " << fontName << endl;
//    }
//
//    void changeSize()
//    {
//        cout << "\nEnter font size : ";
//        cin >> fontSize;
//
//        cout << "\nFont Size Changed\n";
//    }
//
//    void showSettings()
//    {
//        cout << "\n======= CURRENT SETTINGS =======\n";
//
//        cout << "Font Name  : " << fontName << endl;
//        cout << "Font Size  : " << fontSize << endl;
//        cout << "Text Color : " << textColor << endl;
//    }
//
//    void selectAll()
//    {
//        cout << "\nAll Text Selected\n";
//
//        cout << "\n-----------------------------\n";
//        cout << text;
//        cout << "-----------------------------\n";
//    }
//
//    void wordWrap()
//    {
//        cout << "\nWord Wrap Applied\n";
//
//        int count = 0;
//
//        for (int i = 0; i < text.length(); i++)
//        {
//            cout << text[i];
//
//            count++;
//
//            if (count == 40)
//            {
//                cout << endl;
//                count = 0;
//            }
//        }
//
//        cout << endl;
//    }
//};
//
//int main()
//{
//    Editor e;
//
//    int choice;
//
//    do
//    {
//        cout << "\n========== TEXT EDITOR ==========\n";
//
//        cout << "1. New File\n";
//        cout << "2. Type Text\n";
//        cout << "3. Display Text\n";
//        cout << "4. Save File\n";
//        cout << "5. Save As\n";
//        cout << "6. Open File\n";
//        cout << "7. Close File\n";
//        cout << "8. Delete Text\n";
//        cout << "9. Find Word\n";
//        cout << "10. Replace Word\n";
//        cout << "11. Change Text Color\n";
//        cout << "12. Change Font\n";
//        cout << "13. Change Font Size\n";
//        cout << "14. Show Settings\n";
//        cout << "15. Select All\n";
//        cout << "16. Word Wrap\n";
//        cout << "0. Exit\n";
//
//        cout << "\nEnter choice : ";
//        cin >> choice;
//
//        switch (choice)
//        {
//        case 1:
//            e.newFile();
//            break;
//
//        case 2:
//            e.typeText();
//            break;
//
//        case 3:
//            e.displayText();
//            break;
//
//        case 4:
//            e.saveFile();
//            break;
//
//        case 5:
//            e.saveAs();
//            break;
//
//        case 6:
//            e.openFile();
//            break;
//
//        case 7:
//            e.closeFile();
//            break;
//
//        case 8:
//            e.deleteText();
//            break;
//
//        case 9:
//            e.findWord();
//            break;
//
//        case 10:
//            e.replaceWord();
//            break;
//
//        case 11:
//            e.changeColor();
//            break;
//
//        case 12:
//            e.changeFont();
//            break;
//
//        case 13:
//            e.changeSize();
//            break;
//
//        case 14:
//            e.showSettings();
//            break;
//
//        case 15:
//            e.selectAll();
//            break;
//
//        case 16:
//            e.wordWrap();
//            break;
//
//        case 0:
//            cout << "\nProgram Ended\n";
//            break;
//
//        default:
//            cout << "\nInvalid Choice\n";
//        }
//
//    } while (choice != 0);
//
//    return 0;
//}