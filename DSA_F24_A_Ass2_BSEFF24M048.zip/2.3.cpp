#include <iostream>
#include <vector>
using namespace std;

int n;
vector<vector<char>> grid;
int areaSize;

void floodFill(int r, int c) {
    if (r < 0 || r >= n+2 || c < 0 || c >= n+2) return;
    if (grid[r][c] != 'w') return;
    grid[r][c] = 'v'; 
    areaSize++;
    floodFill(r-1, c);
    floodFill(r+1, c);
    floodFill(r, c-1);
    floodFill(r, c+1);
}

int main() {
    cout << "Enter n (size of n x n square): ";
    cin >> n;

    
    grid.assign(n+2, vector<char>(n+2, 'b'));

    cout << "Enter the " << n << "x" << n << " grid row by row (w=white, b=black):\n";
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cin >> grid[i][j];
        }
    }

    vector<int> areas;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (grid[i][j] == 'w') {
                areaSize = 0;
                floodFill(i, j);
                areas.push_back(areaSize);
            }
        }
    }

    cout << "\nNumber of white areas: " << areas.size() << "\n";
    for (int i = 0; i < (int)areas.size(); i++) {
        cout << "Area " << i+1 << ": " << areas[i] << " cell(s)\n";
    }

    return 0;
}
