//#include <iostream>
//#include <cstdlib>
//#include <ctime>
//#include <chrono>
//using namespace std;
//
//struct Node {
//    int data;
//    Node* left;
//    Node* right;
//    Node(int val) : data(val), left(nullptr), right(nullptr) {}
//};
//
//class BST {
//public:
//    Node* root;
//
//    BST() : root(nullptr) {}
//
//    Node* insert(Node* node, int val) {
//        if (!node) return new Node(val);
//        if (val < node->data)
//            node->left = insert(node->left, val);
//        else if (val > node->data)
//            node->right = insert(node->right, val);
//        return node;
//    }
//
//    void insert(int val) {
//        root = insert(root, val);
//    }
//
//    Node* search(Node* node, int val) {
//        if (!node || node->data == val) return node;
//        if (val < node->data) return search(node->left, val);
//        return search(node->right, val);
//    }
//
//    bool search(int val) {
//        return search(root, val) != nullptr;
//    }
//
//    void inorder(Node* node) {
//        if (!node) return;
//        inorder(node->left);
//        cout << node->data << " ";
//        inorder(node->right);
//    }
//
//    void inorder() {
//        inorder(root);
//        cout << "\n";
//    }
//
//    Node* findMin(Node* node) {
//        while (node->left) node = node->left;
//        return node;
//    }
//
//    Node* deleteNode(Node* node, int val) {
//        if (!node) return nullptr;
//        if (val < node->data)
//            node->left = deleteNode(node->left, val);
//        else if (val > node->data)
//            node->right = deleteNode(node->right, val);
//        else {
//            if (!node->left) {
//                Node* temp = node->right;
//                delete node;
//                return temp;
//            } else if (!node->right) {
//                Node* temp = node->left;
//                delete node;
//                return temp;
//            }
//            Node* temp = findMin(node->right);
//            node->data = temp->data;
//            node->right = deleteNode(node->right, temp->data);
//        }
//        return node;
//    }
//
//    void deleteNode(int val) {
//        root = deleteNode(root, val);
//    }
//
//    void clear(Node* node) {
//        if (!node) return;
//        clear(node->left);
//        clear(node->right);
//        delete node;
//    }
//
//    void clear() {
//        clear(root);
//        root = nullptr;
//    }
//
//    ~BST() { clear(); }
//};
//
//int main() {
//    srand(time(0));
//
//    const int SETS = 5;
//    const int COUNT = 100;
//
//    double totalInsertTime = 0, totalTraversalTime = 0;
//
//    cout << "\n";
//    cout << "Set #\t\tTime for Insertions (ms)\tTime for Inorder Traversal (ms)\n";
//    cout << "----------------------------------------------------------------------\n";
//
//    for (int s = 1; s <= SETS; s++) {
//        BST bst;
//        int nums[COUNT];
//
//        // Generate 100 random numbers
//        for (int i = 0; i < COUNT; i++)
//            nums[i] = rand() % 10000;
//
//        // Time insertions
//        auto startIns = chrono::high_resolution_clock::now();
//        for (int i = 0; i < COUNT; i++)
//            bst.insert(nums[i]);
//        auto endIns = chrono::high_resolution_clock::now();
//        double insTime = chrono::duration<double, milli>(endIns - startIns).count();
//
//        // Time inorder traversal (suppress output)
//        // Redirect traversal to count nodes silently
//        auto startTrav = chrono::high_resolution_clock::now();
//        // Traverse without printing for timing accuracy
//        // We'll use a lambda via a helper
//        // Actually just do inorder but suppress cout
//        auto travHelper = [](auto& self, Node* node) -> void {
//            if (!node) return;
//            self(self, node->left);
//            volatile int x = node->data; (void)x; // prevent optimization
//            self(self, node->right);
//        };
//        travHelper(travHelper, bst.root);
//        auto endTrav = chrono::high_resolution_clock::now();
//        double travTime = chrono::duration<double, milli>(endTrav - startTrav).count();
//
//        totalInsertTime += insTime;
//        totalTraversalTime += travTime;
//
//        cout << s << "\t\t" << insTime << "\t\t\t\t" << travTime << "\n";
//    }
//
//    cout << "----------------------------------------------------------------------\n";
//    cout << "Average\t\t" << totalInsertTime/SETS << "\t\t\t\t" << totalTraversalTime/SETS << "\n";
//
//    // Demo: search and delete
//    cout << "\n--- Demo of Search and Delete ---\n";
//    BST demo;
//    int demoNums[] = {50, 30, 70, 20, 40, 60, 80};
//    for (int x : demoNums) demo.insert(x);
//
//    cout << "Inorder traversal: ";
//    demo.inorder();
//
//    cout << "Search 40: " << (demo.search(40) ? "Found" : "Not Found") << "\n";
//    cout << "Search 99: " << (demo.search(99) ? "Found" : "Not Found") << "\n";
//
//    demo.deleteNode(30);
//    cout << "After deleting 30: ";
//    demo.inorder();
//
//    return 0;
//}
