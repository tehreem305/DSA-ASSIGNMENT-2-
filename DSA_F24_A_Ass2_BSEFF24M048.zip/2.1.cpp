//#include<iostream>
//#include<string>
//
//using namespace std;
//class Window
//{
//public:
//	string title;
//	string color;
//	int width;
//	int height;
//	Window* next;
//	Window* prev;
//
//	Window()
//	{
//		title = " new window";
//		color = "white";
//		width = 400;
//		height = 300;
//		next = NULL;
//		prev = NULL;
//
//
//	}
//	Window(string t, string c, int w, int h)
//	{
//		title = t;
//		color = c;
//		width = w;
//		height = h;
//		next = NULL;
//		prev = NULL;
//	}
//};
//class WindowManager
//{
//private:
//	Window* head;
//public:
//	WindowManager()
//	{
//		head = NULL;
//	}
//	void createWindow()
//	{
//		string t;
//		string c;
//		int w;
//		int h;
//		cin.ignore();
//		cout << "enter window title:";
//		getline(cin, t);
//		cout << "enter window color";
//		getline(cin, c);
//		cout << "enter width:";
//		cin >> w;
//		cout << "enter height:";
//		cin >> h;
//
//		Window* newWindow = new Window(t, c, w, h);
//		if (head == NULL)
//		{
//			head = newWindow;
//		}
//		else
//		{
//			newWindow->next = head;
//			head->prev = newWindow;
//		}
//		cout << "\nWindow created successfully\n";
//	}
//	void displayWindows()
//	{
//		if (head == NULL)
//		{
//			cout << "\nno windows available\n";
//			return;
//		}
//		Window* temp = head;
//		cout << "--Windows list--";
//		int count = 1;
//		while (temp != NULL)
//		{
//			if (temp == head)
//			{
//				cout << "\nactive window\n";
//			}
//			cout << "window #" << count << endl;
//			cout << "title :" << temp->title << endl;
//			cout << "color :" << temp->color << endl;
//			cout << "size :" << temp->width << endl;
//
//			cout << "-------------------------------\n";
//			temp=temp->next;
//			count++;
//		}
//	}
//	void activateWindow()
//	{
//		if (head == NULL)
//		{
//			cout << "\nno windows available\n";
//			return;
//		}
//		cin.ignore();
//		string name;
//
//		cout << "\nenter title of window to activate: ";
//		getline(cin, name);
//		Window* temp = head;
//		while (temp != NULL)
//		{
//			if (temp->title == name)
//			{
//				break;
//			}
//			temp = temp->next;
//		}
//		if (temp == NULL)
//		{
//			cout << "\nwindow not found\n";
//			return;
//		}
//		if (temp == head)
//		{
//			cout << "window already active\n";
//			return;
//		}
//		if (temp->prev != NULL)
//		{
//			temp->prev->next = temp->next;
//		}
//		if (temp->next != NULL)
//		{
//			temp->next->prev = temp->prev;
//		}
//		temp->next = head;
//		temp->prev = NULL;
//
//		head->prev = temp;
//		head = temp;
//		cout << "\n window activated\n";
//	}
//
//	void resizeWindow()
//	{
//		if (head == NULL)
//		{
//			cout << "\nNO windows available\n";
//			return;
//		}
//		cin.ignore();
//		string name;
//
//		cout << "\nenter title of window to resize:";
//		getline(cin, name);
//		Window* temp = head;
//		while (temp != NULL)
//		{
//			if (temp->title == name)
//			{
//				break;
//			}
//			temp = temp->next;
//		}
//		if (temp == NULL)
//		{
//			cout << "\nwindow not found\n";
//			return;
//		}
//		cout << "enetr new width:";
//		cin >> temp->width;
//		cout << "enetr new height:";
//		cin >> temp->height;
//
//		cout << "\nWindow resize successfullly\n";
//	}
//	void deleteWindow()
//	{
//		if (head == NULL)
//		{
//			cout << "\nNO windows available\n";
//			return;
//		}
//		cin.ignore();
//		string name;
//
//		cout << "\nenter title of window to delete:";
//		getline(cin, name);
//		Window* temp = head;
//		while (temp != NULL)
//		{
//			if (temp->title == name)
//			{
//				break;
//			}
//			temp = temp->next;
//		}
//		if (temp == NULL)
//		{
//			cout << "\nwindow not found\n";
//			return;
//		}
//		if (temp == head)
//		{
//			head = head->next;
//			if (head != NULL)
//			{
//				head->prev = NULL;
//			}
//		}
//		else
//		{
//			temp->prev->next = temp->next;
//			if (temp->next != NULL)
//			{
//				temp->next->prev = temp->prev;
//			}
//		}
//		delete temp;
//		cout << "\nWindows deleetd successfully\n";
//	}
//	~WindowManager()
//	{
//		Window* temp = head;
//
//		while (temp != NULL)
//		{
//			Window* del = temp;
//
//			temp = temp->next;
//
//			delete del;
//		}
//	}
//	
//};
//int main()
//{
//	WindowManager wm;
//
//	int choice;
//
//	do
//	{
//		cout << "\n========== WINDOW MANAGER ==========\n";
//
//		cout << "1. Create Window\n";
//		cout << "2. Activate Window\n";
//		cout << "3. Resize Window\n";
//		cout << "4. Delete Window\n";
//		cout << "5. Display Windows\n";
//		cout << "0. Exit\n";
//
//		cout << "\nEnter choice : ";
//		cin >> choice;
//
//		switch (choice)
//		{
//		case 1:
//			wm.createWindow();
//			break;
//
//		case 2:
//			wm.activateWindow();
//			break;
//
//		case 3:
//			wm.resizeWindow();
//			break;
//
//		case 4:
//			wm.deleteWindow();
//			break;
//
//		case 5:
//			wm.displayWindows();
//			break;
//
//		case 0:
//			cout << "\nProgram Ended\n";
//			break;
//
//		default:
//			cout << "\nInvalid Choice\n";
//		}
//
//	} while (choice != 0);
//
//	return 0;
//}